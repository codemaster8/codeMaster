#!/bin/sh
echo $1 $2
python $1 $2